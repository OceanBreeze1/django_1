from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255, null=True)


class Country(models.Model):
    country_id = models.IntegerField(primary_key=True,auto_created=True)
    country = models.CharField(max_length=255)
    last_update = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.country_id

class City(models.Model):
    city = models.CharField(max_length=255)
    country_id = models.ForeignKey(Country,models.CASCADE,'id')
    last_update = models.TimeField(max_length=255, null=True)

    def __repr__(self):
        return f'city{self.city} last_update{self.last_update}'