from django.contrib import admin
from apps.models import Product
from apps.models import Country
from apps.models import City
# admin.site.register(Country)
# admin.site.register(Product)
# admin.site.register(City)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id','name','description')

@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    fields = ('country_id',)
    list_display = ('country_id','country','last_update')
